var files =
[
    [ "Simplify.framework", "dir_be2f5f3090a22af33f2af18f49fd7066.html", "dir_be2f5f3090a22af33f2af18f49fd7066" ],
    [ "SimplifyMerchantSDK", "dir_ad1b7289fb7c1b79f2cdb71c35db4298.html", "dir_ad1b7289fb7c1b79f2cdb71c35db4298" ],
    [ "SimplifySDKSampleApp", "dir_5435d6d63885d74714b6ab7ad67a67e8.html", "dir_5435d6d63885d74714b6ab7ad67a67e8" ]
];