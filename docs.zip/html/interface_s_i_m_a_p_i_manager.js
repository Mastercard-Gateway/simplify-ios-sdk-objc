var interface_s_i_m_a_p_i_manager =
[
    [ "CardTokenCompletionHandler", "interface_s_i_m_a_p_i_manager.html#a46f453c49f63c47d429c1cff41e71f77", null ],
    [ "createCardTokenWithExpirationMonth:expirationYear:cardNumber:cvc:address:completionHander:", "interface_s_i_m_a_p_i_manager.html#ab00e271a753354d59ec2acd39013fdf1", null ],
    [ "initWithApiKey:error:", "interface_s_i_m_a_p_i_manager.html#ac7a1485ec709d6843a0abd560f52585e", null ],
    [ "isLiveMode", "interface_s_i_m_a_p_i_manager.html#aa1a33aa91ef10dff760719c019774f6a", null ]
];