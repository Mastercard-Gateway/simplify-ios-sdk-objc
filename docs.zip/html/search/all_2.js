var searchData=
[
  ['delegate',['delegate',['../interface_s_i_m_charge_card_view_controller.html#a2aca448738a2d92c7f0e3fe15efeaea5',1,'SIMChargeCardViewController::delegate()'],['../interface_s_i_m_charge_card_model.html#a21055a4b99124afa09e838a3d3918795',1,'SIMChargeCardModel::delegate()']]]
];
