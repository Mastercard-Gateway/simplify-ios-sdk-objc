var searchData=
[
  ['hasprefixfromarray_3ainstring_3a',['hasPrefixFromArray:inString:',['../interface_s_i_m_card_type.html#aecf71802d122c3db429175e073ae3261',1,'SIMCardType::hasPrefixFromArray:inString:(NSArray *prefixArray,[inString] NSString *cardString)'],['../interface_s_i_m_card_type.html#aecf71802d122c3db429175e073ae3261',1,'SIMCardType::hasPrefixFromArray:inString:(NSArray *prefixArray,[inString] NSString *cardString)']]]
];
