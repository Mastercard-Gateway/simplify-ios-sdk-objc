var searchData=
[
  ['cardtokencompletionhandler',['CardTokenCompletionHandler',['../interface_s_i_m_a_p_i_manager.html#a46f453c49f63c47d429c1cff41e71f77',1,'SIMAPIManager::CardTokenCompletionHandler()'],['../interface_s_i_m_simplify.html#adfa0ea4b604f2fd39a101931382c25e1',1,'SIMSimplify::CardTokenCompletionHandler()'],['../interface_s_i_m_simplify.html#adfa0ea4b604f2fd39a101931382c25e1',1,'SIMSimplify::CardTokenCompletionHandler()']]]
];
