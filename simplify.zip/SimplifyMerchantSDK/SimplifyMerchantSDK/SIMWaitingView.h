#import <UIKit/UIKit.h>

/* View for alerting user to a long-running process that needs to block UI.
 */

@interface SIMWaitingView : UIView

@end
